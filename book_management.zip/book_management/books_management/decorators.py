from django.http import HttpResponse
from django.shortcuts import redirect
def is_authenticated(func):
    def inner(request, *args, **kwargs):
        try:
            request.Auth_token=Header.objects.get(Auth_token=Auth_token)
            return func(request, *args, **kwargs)
        except Token.DoesNotExists:
            pass
    return inner
