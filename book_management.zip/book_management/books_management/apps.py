from django.apps import AppConfig


class BooksManagementConfig(AppConfig):
    name = 'books_management'
