from django.db import models
# Create your models here.
from django.db import models

class Register(models.Model):
    name = models.CharField(max_length=60)
    email = models.EmailField(max_length=60)
    password = models.CharField(max_length=60)
    def __str__(self):
        return self.name


class Login(models.Model):
    email = models.EmailField(max_length=60)
    password = models.CharField(max_length=60)
    def __str__(self):
        return self.email

class Book(models.Model):
    book_id = models.IntegerField(max_length=60)
    date1 = models.DateField(max_length=60)
    def __str__(self):
        return self.book_id


class Header(models.Model):
    Auth_token = models.CharFieldField(max_length=60)

	def __str__(self):
        return self.Auth_token


class Library(models.Model):
    book_name = models.CharField(max_length=60)
    author = models.CharField(max_length=60)
	Book_count = models.IntegerField(max_length=60)

	def __str__(self):
        return self.book_id
