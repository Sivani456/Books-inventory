from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapi.models import *
from django.contrib.auth.forms import *
from django.views.decorators.csrf import requires_csrf_token

def register_view(request):
	form=createuserform()
    if request.method == 'POST':
        form = createuserform(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Account Created successfully for " + username)
            return redirect('login')
		else:
		messages.info(request,"Invalid data")
	context={'form':form}
	return render(request,'register.html',context)
def login_view(request):
        if request.method=='POST':
            username=request.POST.get('email')
            password=request.POST.get('password')

            user=register(request,email=email,password=password)

            if user is not None:
                if result['success']:
                    login(request,user)
                    return redirect('main')
            else:
                messages.info(request,'Username or Password Invalid')

        context={}

        return render(request,'login.html',context)

@is_authenticated
def library_view(request):
	book_name=request.POST.get('book_name',None)
    author=request.POST.get('author',None)
    Book_count=Model.book.count()
    lib=Library(book_name=book_name,author=author,Book_count=Book_count)
	lib.save()
	return redirect('library')

@is_authenticated
def get_all_books_view(request):
	allbooks=Library.objects.all()
    books={'allbooks':allbooks}
    return render(request,'get_all_books.html',context=books)

@is_authenticated
def get_a_book_view(request,book_name):
	abook=Library.objects.filter(book_name=book_name)
    books={'abook':abook}
    return render(request,'get_a_book.html',context=books)




    
