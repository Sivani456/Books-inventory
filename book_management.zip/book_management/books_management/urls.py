from django.urls import include, path
from rest_framework import routers
from . import views

router = routers.DefaultRouter()
router.register(r'register', views.register_view)
router.register(r'login', views.login_view)
router.register(r'book', views.book_view)

urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
	path('library/',views.library_view,name='library'),
	path('get_all_books/',views.get_all_books_view,name='get_all_books'),
	path('get_a_book/<string:book_name>/',views.get_a_book_view,name='get_a_book'),
]
